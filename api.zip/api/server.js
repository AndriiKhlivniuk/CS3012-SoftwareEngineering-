var express = require('express');
var request = require('request');
var app = express();
var bodyParser = require('body-parser');

app.use(express.static('public'));


app.get('/index.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "index.htm" );

})

app.get('/data.htm', function (req, res) {
   var name= req.query.name;
   if(name==null||name==""){
      response.send("no name entered");
   }
  request({url:'https://api.github.com/users/'+name,
            headers :{"User-Agent":"node js"}}, function (error, response, body) {
               console.log(body);
  res.send(body);
});
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("Example app listening at http://%s:%s", host, port)

})